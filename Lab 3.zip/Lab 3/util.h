#include <gsl/gsl_linalg.h>
#include <iostream>

void print_matrix(gsl_matrix * m);
void print_vector(gsl_vector * v);
