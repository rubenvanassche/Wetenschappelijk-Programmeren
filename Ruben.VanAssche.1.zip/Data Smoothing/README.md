# Data Smoothin - Oefening 5

## Vereisten:
- Cmake 3.8
- GSL
- C++11 Compiler
- GNUPlot

## Compilen:
```
cmake .
make
```

## Runnen:
```
./main
```

## Genereren van de grafieken:
```
gnuplot graphs.gnuplot
```
