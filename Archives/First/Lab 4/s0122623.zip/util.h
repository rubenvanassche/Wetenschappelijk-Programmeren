#include <gsl/gsl_linalg.h>
#include <iostream>

void print_matrix(gsl_matrix * m);
