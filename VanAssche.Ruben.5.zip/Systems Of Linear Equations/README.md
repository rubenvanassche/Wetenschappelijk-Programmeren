# Systemen Lineaire Vergelijkingen - Oefening 5

## Vereisten:
- Cmake 3.8
- GSL
- C++11 Compiler

## Compilen:
```
cmake .
make
```

## Runnen:
```
./main
```
