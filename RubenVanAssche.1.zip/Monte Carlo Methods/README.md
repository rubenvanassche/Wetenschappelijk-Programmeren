# Random number generators - Oefening 1

## Vereisten:
- Make
- Intel MKL
- liomp5
- C++11 Compiler

## Compilen:
```
chmod +x make.sh
./make.sh
```

## Runnen:
```
./main
```
